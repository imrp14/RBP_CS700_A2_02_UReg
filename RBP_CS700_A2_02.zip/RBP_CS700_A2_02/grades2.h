// grades2.h
// Author: Rishi B. Patel (200529611)
// Date: 02/October/2024
// Purpose: This header file contains the function declarations. It is used to get student grade data and letter grade assignment based on the each exam average.



#ifndef GRADES2_H       // ifndef: if not defined, to check if macro is non-existent.
#define GRADES2_H       // define: used to define the macros

#include <iostream>     // Used for including i/p & o/p stream library for operations like input (cin) and output (cout)
#include <fstream>      // Used for reading and writing from/to any file
#include <iomanip>      // Used for manipulating the output.
#include <string>       // Used for strings and string funcs.

using namespace std;    // Used for removing the need to write std:: everytime before each cin, cout, string, etc.


const int MAX_STUDENTS = 25; // Max. number of students
const int MAX_SCORES = 10;   // Max. number of exam scores per student

// Function prototype to assign a grade based on score and average
string assignGrade(int score, double avg);

#endif // GRADES_H
