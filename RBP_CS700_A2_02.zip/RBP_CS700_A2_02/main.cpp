// main.cpp
// Author:    Rishi B. Patel (200529611)
// Date:      02/October/2024
/* Purpose:   This main.cpp contains functions, namely assignGrade() and main().
              This is slight modification of program 1 and here grade is assigned to every student for each exam attempt.
              As a result, all 25 students will have 10 letter grades assigned to them for the 10 exams they have attempted.
*/



#include "grades2.h"        // Used for including the header file which has function declarations.


// Creator:         Rishi B. Patel (200529611)
// Date:            02/October/2024
// Function Name:   main()
/* Parameters:      None.
*/
// Return:          Returns 0, upon successful execution. Returns 1 for error opening ip or op file.
/* Purpose:         Used to read Student IDs and the corresponding exam marks.
                    Calculates the average marks for each exam and assign letter grade to every student based on relative grading.
                    Finally writes the results to output file.
*/

int main()
{
    // Used for opening input file
    ifstream ipFile("grades2.txt");

    // Used for opening output file where results will be written
    ofstream opFile("output2.txt");

    // To check if ip file opened or not
    if (!ipFile.is_open())
    {
        cout << "Error: Unable to open input file!" << endl;
        return 1;
    }

    // To check if op file opened or not
    if (!opFile.is_open())
    {
        cout << "Error: Unable to open output file!" << endl;
        return 1;
    }

    // Used for taking the no. of students and their no. of exam marks
    int numStudents, numScores;
    ipFile >> numStudents >> numScores;

    int scores[MAX_STUDENTS][MAX_SCORES];       // 2D array for storing all exam marks of all students.
    string stud_ID[MAX_STUDENTS];               // Array to store student IDs
    double exam_avg[MAX_SCORES] = {0};          // Array to store the average of each exam

    // Iterate over the entire student list to read the attempts and marks scored.
    for (int i = 0; i < numStudents; ++i)
    {
        ipFile >> stud_ID[i];                   // Used for reading stud_id

    for (int j = 0; j < numScores; ++j)
        {
            ipFile >> scores[i][j];             // Read each exam score for the given student
            exam_avg[j] = exam_avg[j] + scores[i][j];        // Used for adding score to total for the given exam
        }
    }

    // For calculating the average for each exam
    for (int j = 0; j < numScores; ++j)
    {
        exam_avg[j] = exam_avg[j] / numStudents;    // Divide total sum by no of students for average
    }

    // Output header for the output file
    opFile << left << setw(12) << "Student ID";
    for (int j = 1; j <= numScores; ++j) {
        opFile << "Exam " << j << "  Grade  ";
    }
    opFile << endl;

    // Output each student's scores and letter grades based on relative marking
    for (int i = 0; i < numStudents; ++i) {
        opFile << left << setw(12) << stud_ID[i];
        for (int j = 0; j < numScores; ++j) {
            string grade = assignGrade(scores[i][j], exam_avg[j]);          // For assigning a letter grade to the exam marks
            opFile << right << setw(5) << scores[i][j] << "  " << setw(6) << grade << "  ";     // For outputting the score and assigned grade
        }
        opFile << endl;
    }
    // Close ip and op files.
    ipFile.close();
    opFile.close();

    return 0;
}


// Creator:         Rishi B. Patel (200529611)
// Date:            02/October/2024
// Function Name:   assignGrade
/* Parameters:      int score:  Marks received by a student on a given exam.
                    double avg: Avg marks of all students for a given exam.
*/
// Return:          Returns a string which has assigned grade A,B,C,D, etc based on the marks scored by the student.
/* Purpose:         This function assigns a letter grade to a student based on their exam score.
                    The grade is determined by relative marking the average.
                    Using this scale:
                    A: Score is 15 or more points above the average.
                    B: Score is between 5 and 15 points above the average.
                    C: Score is within 5 points above or below the average.
                    D: Score is between 5 and 15 points below the average.
                    F: Score is more than 15 points below the average.
*/
string assignGrade(int score, double avg)
{
    if (score >= avg + 15)
        return "A";
    else if (score >= avg + 5)
        return "B";
    else if (score >= avg - 5)
        return "C";
    else if (score >= avg - 15)
        return "D";
    else
        return "F";
}
