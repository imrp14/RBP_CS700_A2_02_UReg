# CS-700-ASSIGNMENT-2.2	Student Grade Assignment using relative marking



## CREATOR
Rishi B Patel 



## ID NUMBER
200529611



## EXPLANATION
This program is used to read students' grades data including student id, no. of attempts are fixed to 10, and marks scored in each exam.
This program calculates average marks for each and every student for every given exam.
Based on this avg marks, a letter grade is assigned to every student. 

		    A: Score is 15 or more points above the average.
                    B: Score is between 5 and 15 points above the average.
                    C: Score is within 5 points above or below the average.
                    D: Score is between 5 and 15 points below the average.
                    F: Score is more than 15 points below the average.




## Features
* Reads students' entire data from input file.
* Calculates avg. marks. and assigns letter grade.
* Outputs results to an output file.




## INPUT:	Each line of grades.txt file. Contains Student's IDs, followed by the no. of exams which is 10 for all students and the scores achieved in those exams.



## OUTPUT:	Console Display: 	Nothing
		Output File (.txt): 	Student ID, and for every exam taken by student a corresponding grade.


## COMPILATION AND EXECUTION

### FILES
	main.cpp:			Source code file with all the logical implementation. This contains function definitions.
	grades2.h:			This is a header and it  contains function declarations.
	grades2.txt:			Input file from which data is read.
	output2.txt:			Output file where all data is stored.

I have used CodeBlocks IDE and it has a built-in compiler for C/C++.
To build and run the program, upload all the files and press on build and run icon in the IDE. There's no need for writing the commands on the terminal.
Upon succesful execution, the output will be displayed to a console display as well as an output file will be created.



## TEST OUTPUTS
Student ID  Exam 1  Grade  Exam 2  Grade  Exam 3  Grade  Exam 4  Grade  Exam 5  Grade  Exam 6  Grade  Exam 7  Grade  Exam 8  Grade  Exam 9  Grade  Exam 10  Grade  
584827925      99       A    100       A     91       A     68       D     72       D    100       A     93       B     74       D     77       D     96       B  
952344495      60       F    100       A     38       F     92       B     80       C     70       D     84       C     76       D     77       D     80       C  
